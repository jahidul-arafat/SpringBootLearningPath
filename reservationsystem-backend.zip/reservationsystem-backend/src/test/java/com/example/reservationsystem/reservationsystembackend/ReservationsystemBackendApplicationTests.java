package com.example.reservationsystem.reservationsystembackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationsystemBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
